export class Registermodel {
   public  fname:string;
  public  lname:string;
  public Email:any;
  public Pass1:any;
  public Pass2:any;
    constructor(Firstname?:string,Lastname?:string,email?:any,Password1?:any,Password2?:any)
    {
       this.fname=Firstname;
       this.lname=Lastname;
       this.Email=email;
       this.Pass1=Password1;
       this.Pass2=Password2;
    }
}
