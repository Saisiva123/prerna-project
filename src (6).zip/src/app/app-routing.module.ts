import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChatlogsComponent } from '../app/loginpage/dashboard/chatlogs/chatlogs.component';
import { PrioritylistComponent } from '../app/loginpage/dashboard/prioritylist/prioritylist.component';
import { ChatStatisticsComponent } from './loginpage/dashboard/chat-statistics/chat-statistics.component';
import { UserChatInfoComponent } from './loginpage/dashboard/chatlogs/user-chat-info/user-chat-info.component';
import { DashboardComponent } from '../app/loginpage/dashboard/dashboard.component';
import { LoginpageComponent } from "./loginpage/loginpage.component";
import { ChatlistComponent } from './loginpage/dashboard/prioritylist/chatlist/chatlist.component';
import { LoginComponent } from './loginpage/login/login.component';
import { RegisterComponent } from './loginpage/register/register.component'; 

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'chatstatistics',component:ChatStatisticsComponent},
  {path:'chatlogs',component:ChatlogsComponent },
  {path:'prioritylist',component:PrioritylistComponent},
  {path:'chatlogs/:id',component:UserChatInfoComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'prioritylist/:id',component:ChatlistComponent},
  {path:'**',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[LoginComponent,RegisterComponent,DashboardComponent,ChatlistComponent,LoginpageComponent,UserChatInfoComponent,ChatStatisticsComponent,ChatlogsComponent,PrioritylistComponent];