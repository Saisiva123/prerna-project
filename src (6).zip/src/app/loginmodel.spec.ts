import { Loginmodel } from './loginmodel';

describe('Loginmodel', () => {
  it('should create an instance', () => {
    expect(new Loginmodel()).toBeTruthy();
  });
});
