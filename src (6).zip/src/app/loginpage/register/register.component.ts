import { Component, OnInit, Output ,EventEmitter} from '@angular/core';
import { UserdataService } from '../../../assets/userdata.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
public regmodel:any;
public firstname:string;
public lastname:string;
public email:string;
public pass1:string;
public pass2:string;
public enableLogin=false;

public regMessage;
@Output() emitLogin = new EventEmitter;
public content:any;
  constructor(private userdata:UserdataService) { 
    this.content=this.userdata;
    this.regMessage=this.userdata;
  }

  ngOnInit() {
    
  }
  
 validate()
  {
    if(this.pass1 == this.pass2)
    {
      this.enableLogin=true;
      this.emitLogin.emit(this.enableLogin);
      this.content.updateData(this.firstname,this.email,this.pass1); 
      this.regMessage.changeMessage("successfully registered");
    }
}

}
