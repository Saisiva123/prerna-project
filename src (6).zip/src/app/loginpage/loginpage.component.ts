import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-loginpage",
  templateUrl: "./loginpage.component.html",
  styleUrls: ["./loginpage.component.css"]
})
export class LoginpageComponent implements OnInit {
  public toggleDashboard = false;
  public Username: string = "sai";
  public Password: number = 1234;
  username: string;
  password: number;
  enable:boolean=false;
  showLoginPage=true;
  showloginbutton:boolean=true;
  showregisterbutton:boolean=true;
  showRegisterPage=false;
  
  constructor() {}

  ngOnInit() {
    
  }
 
  enableLoginComp(data:boolean)
  {
    if(data)
    {
    this.showLoginPage=true;
    this.showRegisterPage=!this.showLoginPage;
    this.showlogin();
    }
  }
  showDashboard(enable:boolean) {
    //if(this.Username==this.username && this.Password==this.password)
    //{
      if(enable)
      {
        console.log(enable);
       this.toggleDashboard=true;
      }
    else
    {
       this.toggleDashboard=false;
   }
  }
  showlogin() {
    this.showLoginPage=true;
    this.showRegisterPage=!this.showLoginPage;
    document.getElementById("login").style.backgroundColor="white";
    document.getElementById("login").style.color="rgb(85, 167, 243)";
    document.getElementById("register").style.backgroundColor="rgb(87, 85, 85)";
    document.getElementById("register").style.color="white";
  } 
  showregister() {
    this.showRegisterPage=true;
    this.showLoginPage=!this.showRegisterPage;
    document.getElementById("register").style.backgroundColor="white";
    document.getElementById("register").style.color="rgb(85, 167, 243)";
    document.getElementById("login").style.backgroundColor="rgb(87, 85, 85)";
    document.getElementById("login").style.color="white";
  }
}
