import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserChatInfoComponent } from './user-chat-info.component';

describe('UserChatInfoComponent', () => {
  let component: UserChatInfoComponent;
  let fixture: ComponentFixture<UserChatInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserChatInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserChatInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
