import { Component, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {UserdataService} from '../../../../../assets/userdata.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-user-chat-info',
  templateUrl: './user-chat-info.component.html',
  styleUrls: ['./user-chat-info.component.css']
})
export class UserChatInfoComponent implements OnInit {
 public userid:string;
 public content:any;
 public chat:any;
 public userChatInfo:boolean=false;

  constructor(private route:ActivatedRoute,private userdata:UserdataService,private router:Router) { }

  ngOnInit() {
  
   // this.sticky= this.header.offsetTop;
    let id=this.route.snapshot.paramMap.get('id');
    this.userid=id;
    this.content=this.userdata.userInfo;
    for (let index = 0; index < this.content.length; index++) {
     if( this.userid == this.content[index].userid)
     {
       this.userChatInfo=true;
       this.chat=this.content[index].chat;
     }     
    }
}
backpage()
{
  this.router.navigate(['/chatlogs']);
}


}
