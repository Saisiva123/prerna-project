import { Component, OnInit } from '@angular/core';
import {UserdataService} from '../../../../assets/userdata.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-chatlogs',
  templateUrl: './chatlogs.component.html',
  styleUrls: ['./chatlogs.component.css']
})
export class ChatlogsComponent implements OnInit {
public showChatInfo:boolean=false;
public name:string;//has to be changed
public content:any;
  constructor(private userdata:UserdataService,private router:Router) { 
    this.content=this.userdata.userInfo;
  }

  ngOnInit() {
  }
showUserChat(id: any)
{
  this.showChatInfo=true;
  this.router.navigate(['/chatlogs',id.userid]);
}

}
