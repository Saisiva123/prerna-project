import { Component, OnInit ,Output,EventEmitter} from '@angular/core';
import { UserdataService } from '../../../assets/userdata.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
public imgVisible:boolean=true;
public enableLogout=true;
@Output() logoutPage=new EventEmitter();
  constructor(private userdata:UserdataService) { }

  ngOnInit() {
  }
switchPage()
{
  this.imgVisible=false;
}
openHomePage()
{
  this.imgVisible=true;
}
logout()
{
  let logoutConfirm=confirm("Are you sure to logout");
  if(logoutConfirm)
  {
    this.userdata.changeMessage("not registered");
  this.enableLogout=false;
  this.logoutPage.emit(this.enableLogout);
  }
}
openNav() {
  document.getElementById("mySidenav").style.width = "30vh";
  document.getElementById("main").style.left = "30vh";
  document.getElementById("chatimg").style.left = "33%";
  document.getElementById("chatimg").style.width = "65px";
  document.getElementById("chatimg").style.height = "65px";
  document.getElementById("closeBtn").style.display = "block"; 
  document.getElementById("open").style.display="none";
  document.getElementById("chatimg").style.display = "block";
  document.getElementById("botName").style.display = "block";
}
closeNav() {
  document.getElementById("main").style.left = "8vh";
  document.getElementById("mySidenav").style.width = "8vh";
  document.getElementById("closeBtn").style.display = "none";
  document.getElementById("open").style.display="block";
  document.getElementById("chatimg").style.display="none";
  document.getElementById("botName").style.display = "none";

}
}
