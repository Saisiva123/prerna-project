import { Component, OnInit,ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {UserdataService} from '../../../../../assets/userdata.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-chatlist',
  templateUrl: './chatlist.component.html',
  styleUrls: ['./chatlist.component.css']
})
export class ChatlistComponent implements OnInit {
  public userid:string;
  public content:any;
  public chat:any;

  public userChatInfo:boolean=false;
  constructor(private element:ElementRef,private route:ActivatedRoute,private userdata:UserdataService,private router:Router) { }

  ngOnInit() {
    let id=this.route.snapshot.paramMap.get('id');
    this.userid=id;
    this.content=this.userdata.userInfo;
    for (let index = 0; index < this.content.length; index++) {
     if( this.userid == this.content[index].userid)
     {
       this.userChatInfo=true;
       this.chat=this.content[index].chat;
     }     
    }
    this.element.nativeElement.addEventListener('mouseenter', this.scrollToUserInput);
  }
  focus() {
    document.getElementById('tr').focus();
}
backpage()
{
  this.router.navigate(['/prioritylist']);
}
scrollToUserInput() {

  document.getElementById("focus").scrollIntoView({behavior: "smooth"});
}
}