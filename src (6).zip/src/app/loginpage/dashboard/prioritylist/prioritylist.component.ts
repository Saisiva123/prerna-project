import { Component, OnInit } from '@angular/core';
import { UserdataService } from '../../../../assets/userdata.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-prioritylist',
  templateUrl: './prioritylist.component.html',
  styleUrls: ['./prioritylist.component.css']
})
export class PrioritylistComponent implements OnInit {
  public showChatInfo:boolean=false;
  public content:any;
  public data={};

  constructor(private userdata:UserdataService,private router:Router) { 
   this.content=this.userdata.userInfo;
  }

  ngOnInit() {
   
  }
  showChatList(userid:string)
  {
    this.showChatInfo=true;
    this.router.navigate(['/prioritylist',userid]);
  }
}
