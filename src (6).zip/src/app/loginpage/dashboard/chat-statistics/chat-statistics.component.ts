import { Component, OnInit} from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { UserdataService } from "../../../../assets/userdata.service";


@Component({
  selector: 'app-chat-statistics',
  templateUrl: './chat-statistics.component.html',
  styleUrls: ['./chat-statistics.component.css']
})

export class ChatStatisticsComponent implements OnInit {

 public content:any;
 public userNonAccess=[];
  public barChartOptions: ChartOptions = {
    responsive: true,
  };
  public barChartLabels: Label[]=[];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartPlugins = [];

    public barChartData: ChartDataSets[] = [
      { data: [] , label: 'Series A', stack: 'a' },
      { data: [], label: 'Series B', stack: 'a' }
    ];
  constructor(
    private userdata:UserdataService
  ) { 
    this.content=this.userdata.chatbotUsageNo;
    for (let index = 0; index < this.content[0].length; index++) {
        this.barChartLabels[index] = this.content[0][index];
    }
    for (let index = 0; index < this.content[1].length; index++)
    {
      this.userNonAccess[index]=100-this.content[1][index];
    }  
    for (let index = 0; index < this.content[1].length; index++) {
      this.barChartData[0]["data"][index] = this.content[1][index];
  }
  for (let index = 0; index < this.content[1].length; index++) {
    this.barChartData[1]["data"][index]= this.userNonAccess[index];
}
}

  ngOnInit() {  

  }

}
