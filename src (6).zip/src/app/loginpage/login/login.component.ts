import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { UserdataService } from '../../../assets/userdata.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public username: string;
  public loginPassword: string;
  public messContent;
  mess=document.getElementById("success");
  @Output() valueChange = new EventEmitter();
  counter: boolean = false;
  content: any;
  showregmess:boolean;
  constructor(private userdata: UserdataService) {
    this.content = this.userdata.registersList;

  }

  ngOnInit() {
    this.userdata.currentMessage.subscribe(message => this.messContent = message)
    console.log( this.messContent);
    if( this.messContent=="not registered")
    {
      this.showregmess=false;
    }
    else
    {
      this.showregmess=true;
    }
  }
 
  login() {

 
    for (let index = 0; index < this.content.length; index++) {
        if (this.content[index].email == this.username && this.content[index].password == this.loginPassword) {
          this.counter = true;
          console.log(this.content);
          this.valueChange.emit(this.counter);
        }
        else
        {
          console.log("erro");
        }
      

    }
  }

}
   


