export class Loginmodel {
}
