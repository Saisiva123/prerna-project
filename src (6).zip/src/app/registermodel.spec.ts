import { Registermodel } from './registermodel';

describe('Registermodel', () => {
  it('should create an instance', () => {
    expect(new Registermodel()).toBeTruthy();
  });
});
