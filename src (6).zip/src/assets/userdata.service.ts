import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { HttpClientModule } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class UserdataService {
  private messageSource = new BehaviorSubject("not registered");
  currentMessage = this.messageSource.asObservable();

  constructor(private http: HttpClientModule) {}

  changeMessage(message: string) {
    this.messageSource.next(message);
  }
  public chatbotUsageNo = [
    ["2015", "2016", "2017", "2018", "2019"],
    ["27", "55", "36", "82", "67"]
  ];
 
  public registersList = [
    {
      firstname: "sai",
      email: "saisiva",
      password: "1234"
    },
    {
      firstname: "siva",
      email: "dileep.123@gmail.com",
      password: "dileep"
    }
  ];
  public updateData(firstName: string, email: string, password: any) {
    this.registersList.push({
      firstname: firstName,
      email: email,
      password: password
    });
  }

  public userInfo = [
    {
      userid: "mannem.sai99@gmail.com",
      date: "13-03-19",
      page: "autodesk.com",
      timing: "7:30 A.M",
      chat: [
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: "Fine ,Thank you"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "bot",
          data: " "
        },
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        }
      ]
    },
    {
      userid: "saisiva.799@gmail.com",
      date: "2-09-18",
      page: "autodesk.com/components",
      timing: "5:23 P.M",
      chat: [
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: " "
        }
      ]
    },
    {
      userid: "durgaprasad.sai99@gmail.com",
      date: "09-11-19",
      page: "autodesk.com/products",
      timing: "4:21 P.M",
      chat: [
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: "Fine ,Thank you"
        },
        {
          type: "bot",
          data: "You are most welcome"
        }
      ]
    },
    {
      userid: "dileep.89@gmail.com",
      date: "04-01-19",
      page: "autodesk.com/components/details",
      timing: "9:46 A.M",
      chat: [
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: " "
        }
      ]
    },
    {
      userid: "manikyapavama,.99@gmail.com",
      date: "19-01-19",
      page: "autodesk.com/products",
      timing: "2:21 P.M",
      chat: [
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: "Fine ,Thank you"
        },
        {
          type: "bot",
          data: "You are most welcome"
        }
      ]
    },
    {
      userid: "mukeshsamrat.129@gmail.com",
      date: "29-10-19",
      page: "autodesk.com/products",
      timing: "11:23 P.M",
      chat: [
        {
          type: "bot",
          data: "Hii! How can I help you?"
        },
        {
          type: "user",
          data: "HEllo ,I need to check autodesk components"
        },
        {
          type: "bot",
          data: "This is your required response"
        },
        {
          type: "user",
          data: "Thank you,I want to check about computers"
        },
        {
          type: "bot",
          data: "You can go through this"
        },
        {
          type: "user",
          data: "Do we need any software requirements for this product?"
        },
        {
          type: "bot",
          data: "Yes,we should need some softwares for this product"
        },
        {
          type: "user",
          data: "Fine ,Thank you"
        },
        {
          type: "bot",
          data: "You are most welcome"
        }
      ]
    }
  ];
}
